import UIKit

// challenge 1
print("Enter Your Qustion here")
var str readLine()
var Arr = ["may be","Yes","No","Ask again leter"]
print (Arr.randomElement()!)


//challenge 2
var months :[Int :String] = [
    1:"Jan"
    2:"Feb"
    3:"mar"
    4:"Apr"
    5:"may"
    6:"Jun"
    7:"Jul"
    8:"Aug"
    9:"Sep"
    10:"Oct"
    11:"Nov"
    12:"Dec" ]

print("Month")
var str2 :String = readLine()!
if let x = Int(str2) {
    print(months[x]) ?? "null"
}
else {
    print("null")
}
