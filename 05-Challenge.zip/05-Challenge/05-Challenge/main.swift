//
//  main.swift
//  05-Challenge
//
//  Created by سرّاء. on 19/06/1444 AH.
//



// Challenges # 1
import Foundation

var arrayAnswer = ["Yes", "No","Maybe","Ask again later"]

print("What's your question?")
var answer1 = readLine()!
let randomAnswer = arrayAnswer.randomElement()!
print(randomAnswer)




// Challenges # 2
print("Please enter the number of the month:")
var answer2 = Int(readLine()!)

switch answer2 {
case 1:
print("The name of the month is January")
case 2:
print("The name of the month is February")
case 3:
print("The name of the month is March")
case 4:
print("The name of the month is April")
case 5:
print("The name of the month is May")
case 6:
print("The name of the month is June")
case 7:
print("The name of the month is July")
case 8:
print("The name of the month is Augest")
case 9:
print("The name of the month is September")
case 10:
print("The name of the month is October")
case 11:
print("The name of the month is November")
case 12:
print("The name of the month is December")
default:
    print("Nothing")
}

